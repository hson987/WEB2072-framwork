<template>
  <div class="container py-3">
    <!-- Header bài tập -->
    <div class="text-center mb-4">
      <span class="badge bg-success px-3 py-2 rounded-pill fw-semibold shadow-sm mb-2">
        BÀI 2 (2 ĐIỂM) · VUE 3 COMPOSITION API
      </span>
      <h2 class="fw-bold text-dark display-6">Quản Lý Trạng Thái Với reactive()</h2>
      <p class="text-secondary mx-auto" style="max-width: 650px;">
        Quản lý đối tượng phức tạp gồm nhiều trường dữ liệu (Tên, Tuổi, Email) qua <code>reactive()</code>, ràng buộc biểu mẫu 2 chiều với <code>v-model</code> và kiểm tra tính hợp lệ.
      </p>
    </div>

    <!-- Thông báo kết quả Submit Form -->
    <div 
      v-if="formSubmitted" 
      class="alert alert-dismissible fade show shadow-sm mb-4 mx-auto text-center"
      :class="isValid ? 'alert-success' : 'alert-danger'"
      style="max-width: 850px;"
      role="alert"
    >
      <span class="fs-5 me-2">{{ isValid ? '🎉' : '⚠️' }}</span>
      <strong>{{ isValid ? 'Thông tin hợp lệ!' : 'Vui lòng nhập đầy đủ thông tin!' }}</strong>
      <span>{{ isValid ? ` Đã cập nhật hồ sơ của "${user.name}" thành công.` : ' Bạn cần điền đầy đủ Tên và Email để tiếp tục.' }}</span>
      <button type="button" class="btn-close" @click="formSubmitted = false" aria-label="Close"></button>
    </div>

    <div class="row g-4 justify-content-center">
      <!-- Cột 1: Biểu mẫu nhập liệu (Form) -->
      <div class="col-lg-6">
        <div class="card border-0 shadow rounded-4 h-100 bg-white overflow-hidden">
          <div class="card-header bg-gradient-success text-white py-3 px-4 d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center gap-2">
              <span class="fs-5">📋</span>
              <h5 class="mb-0 fw-bold">Biểu Mẫu Cập Nhật Hồ Sơ</h5>
            </div>
            <button class="btn btn-sm btn-light text-success fw-bold rounded-pill px-3" @click="fillSampleData">
              ⚡ Điền mẫu nhanh
            </button>
          </div>

          <div class="card-body p-4">
            <form @submit.prevent="submitForm">
              <!-- Trường Họ và Tên: v-model="user.name" -->
              <div class="mb-3">
                <label class="form-label fw-bold text-dark">
                  Tên sinh viên / Người dùng <span class="text-danger">*</span>
                </label>
                <div class="input-group">
                  <span class="input-group-text bg-light border-end-0">👤</span>
                  <input 
                    type="text" 
                    class="form-control border-start-0 ps-0" 
                    v-model="user.name" 
                    placeholder="Nhập họ và tên (VD: Nguyễn Văn An)"
                    required 
                  />
                </div>
                <small class="text-muted">Ràng buộc <code>v-model="user.name"</code></small>
              </div>

              <!-- Trường Tuổi: v-model="user.age" -->
              <div class="mb-3">
                <label class="form-label fw-bold text-dark">
                  Tuổi <span class="text-danger">*</span>
                </label>
                <div class="input-group">
                  <span class="input-group-text bg-light border-end-0">🎂</span>
                  <input 
                    type="number" 
                    class="form-control border-start-0 ps-0" 
                    v-model.number="user.age" 
                    placeholder="Nhập tuổi (VD: 20)"
                    min="1"
                    max="120"
                    required 
                  />
                </div>
                <small class="text-muted">Ràng buộc <code>v-model="user.age"</code></small>
              </div>

              <!-- Trường Email: v-model="user.email" -->
              <div class="mb-4">
                <label class="form-label fw-bold text-dark">
                  Địa chỉ Email <span class="text-danger">*</span>
                </label>
                <div class="input-group">
                  <span class="input-group-text bg-light border-end-0">✉️</span>
                  <input 
                    type="email" 
                    class="form-control border-start-0 ps-0" 
                    v-model="user.email" 
                    placeholder="Nhập email (VD: an.nguyen@fpt.edu.vn)"
                    required 
                  />
                </div>
                <small class="text-muted">Ràng buộc <code>v-model="user.email"</code></small>
              </div>

              <!-- Nút submit form theo đề bài -->
              <div class="d-flex gap-2">
                <button type="submit" class="btn btn-success flex-grow-1 py-3 rounded-pill fw-bold fs-6 shadow-sm">
                  💾 Cập nhật
                </button>
                <button type="button" class="btn btn-outline-secondary px-3 rounded-pill" @click="resetForm" title="Xóa dữ liệu">
                  🔄
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>

      <!-- Cột 2: Thẻ ID Hồ sơ Realtime (Live Output Preview) -->
      <div class="col-lg-6">
        <div class="card border-0 shadow rounded-4 h-100 bg-white overflow-hidden">
          <div class="card-header bg-dark text-white py-3 px-4 d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center gap-2">
              <span class="fs-5">🪪</span>
              <h5 class="mb-0 fw-bold">Thẻ Sinh Viên / Hồ Sơ Live</h5>
            </div>
            <span class="badge bg-success rounded-pill px-3 py-1">Đồng bộ trực tiếp</span>
          </div>

          <div class="card-body p-4 d-flex flex-column justify-content-between">
            <!-- Thẻ Profile phong cách VIP Card -->
            <div class="profile-card p-4 rounded-4 text-white shadow-sm mb-4 position-relative overflow-hidden">
              <div class="d-flex justify-content-between align-items-start mb-3">
                <span class="badge bg-white text-dark fw-bold rounded-pill px-3 py-1">FPT POLYTECHNIC</span>
                <span class="badge bg-warning text-dark fw-bold rounded-pill">THÀNH VIÊN VUE 3</span>
              </div>

              <!-- Avatar & Tên -->
              <div class="d-flex align-items-center gap-3 my-3">
                <div class="avatar-box rounded-circle bg-white text-dark fw-bold d-flex align-items-center justify-content-center shadow">
                  {{ user.name ? user.name.trim().charAt(0).toUpperCase() : '?' }}
                </div>
                <div>
                  <h4 class="fw-bold mb-0 text-white text-break">{{ user.name || 'Họ và tên của bạn' }}</h4>
                  <div class="text-white-50 small">{{ user.email || 'email@domain.com' }}</div>
                </div>
              </div>

              <div class="d-flex gap-4 mt-3 pt-2 border-top border-white border-opacity-25 small">
                <div>
                  <span class="text-white-50 d-block">Độ tuổi:</span>
                  <span class="fw-bold fs-6">{{ user.age !== null ? user.age + ' tuổi' : '-- tuổi' }}</span>
                </div>
                <div>
                  <span class="text-white-50 d-block">Trạng thái:</span>
                  <span class="badge bg-success-subtle text-white">Đang hoạt động</span>
                </div>
              </div>
            </div>

            <!-- Khối hiển thị dữ liệu văn bản thuần theo đúng mẫu đề bài yêu cầu -->
            <div class="bg-light p-3 rounded-4 border">
              <h6 class="fw-bold text-secondary mb-3 pb-2 border-bottom">
                📌 Dữ liệu nội suy từ biến reactive (Chuẩn yêu cầu đề bài):
              </h6>
              <p class="mb-2 fs-6"><strong>Tên:</strong> <span class="text-primary fw-semibold">{{ user.name || '(Trống)' }}</span></p>
              <p class="mb-2 fs-6"><strong>Tuổi:</strong> <span class="text-primary fw-semibold">{{ user.age !== null ? user.age : '(Trống)' }}</span></p>
              <p class="mb-0 fs-6"><strong>Email:</strong> <span class="text-primary fw-semibold">{{ user.email || '(Trống)' }}</span></p>
            </div>
          </div>

          <div class="card-footer bg-light p-3 px-4 border-top text-muted small">
            <strong>🔍 Giải thích kỹ thuật Vue 3:</strong>
            <code>const user = reactive({...})</code> theo dõi toàn bộ thuộc tính bên trong đối tượng. Bất kỳ thay đổi nào từ các ô input thông qua <code>v-model</code> đều lập tức cập nhật sang view mà không cần gán lại cả object.
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { reactive, ref } from "vue";

// Khai báo đối tượng phản ứng đa thuộc tính theo đúng đề bài
const user = reactive({
  name: "",
  age: null,
  email: "",
});

const formSubmitted = ref(false);
const isValid = ref(false);

// Hàm submit form đúng theo yêu cầu đề bài
const submitForm = () => {
  formSubmitted.value = true;
  if (user.name && user.email) {
    isValid.value = true;
    alert("Thông tin hợp lệ");
  } else {
    isValid.value = false;
    alert("Vui lòng nhập đầy đủ thông tin");
  }
};

// Hàm điền mẫu nhanh để test
const fillSampleData = () => {
  user.name = "Nguyễn Văn An";
  user.age = 20;
  user.email = "an.nv@fpt.edu.vn";
};

// Hàm xóa form
const resetForm = () => {
  user.name = "";
  user.age = null;
  user.email = "";
  formSubmitted.value = false;
};
</script>

<style scoped>
.bg-gradient-success {
  background: linear-gradient(135deg, #198754 0%, #146c43 100%);
}

.profile-card {
  background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
}

.avatar-box {
  width: 65px;
  height: 65px;
  font-size: 1.8rem;
}
</style>
