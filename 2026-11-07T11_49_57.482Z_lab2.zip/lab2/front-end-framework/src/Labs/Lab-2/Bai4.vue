<template>
  <div class="container py-3">
    <!-- Header bài tập -->
    <div class="text-center mb-4">
      <span class="badge bg-warning text-dark px-3 py-2 rounded-pill fw-semibold shadow-sm mb-2">
        BÀI 4 (3 ĐIỂM) · VUE 3 COMPOSITION API
      </span>
      <h2 class="fw-bold text-dark display-6">Class và Style Binding</h2>
      <p class="text-secondary mx-auto" style="max-width: 650px;">
        Thực hành ràng buộc lớp động <code>:class="{ active: isActive }"</code> và kiểu nội dòng động <code>:style="{ fontSize: fontSize + 'px' }"</code> kèm logic kiểm tra điều kiện kích thước từ 10px đến 50px.
      </p>
    </div>

    <div class="row g-4 justify-content-center">
      <!-- Cột 1: Bảng điều khiển tương tác (Design Studio Controls) -->
      <div class="col-lg-5">
        <div class="card border-0 shadow rounded-4 h-100 bg-white overflow-hidden">
          <div class="card-header bg-dark text-white py-3 px-4 d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center gap-2">
              <span class="fs-5">🎛️</span>
              <h5 class="mb-0 fw-bold">Bảng Điều Khiển Tùy Biến</h5>
            </div>
            <span class="badge bg-secondary rounded-pill px-3 py-1">Tương tác trực tiếp</span>
          </div>

          <div class="card-body p-4">
            <!-- 1. Bật/Tắt màu chữ (Class Binding) -->
            <div class="p-3 bg-light rounded-4 border mb-4">
              <div class="d-flex justify-content-between align-items-center mb-2">
                <label class="form-label fw-bold text-dark mb-0">1. Ràng buộc Class động:</label>
                <span class="badge" :class="isActive ? 'bg-danger' : 'bg-secondary'">
                  {{ isActive ? 'Đang kích hoạt class .active' : 'Chưa áp dụng class' }}
                </span>
              </div>
              <p class="text-muted small mb-3">
                Nhấn nút bên dưới để đảo ngược giá trị boolean <code>isActive = !isActive</code>. Khi <code>isActive === true</code>, class <code>.active</code> sẽ áp dụng màu đỏ.
              </p>
              
              <!-- Nút theo đúng yêu cầu đề bài -->
              <button 
                class="btn w-100 py-3 rounded-pill fw-bold shadow-sm d-flex justify-content-center align-items-center gap-2"
                :class="isActive ? 'btn-danger' : 'btn-outline-dark'"
                @click="isActive = !isActive"
              >
                <span class="fs-5">{{ isActive ? '🔴' : '⚪' }}</span>
                Bật/Tắt màu chữ
              </button>
            </div>

            <!-- 2. Chọn kích thước chữ (Style Binding) -->
            <div class="p-3 bg-light rounded-4 border mb-3">
              <div class="d-flex justify-content-between align-items-center mb-2">
                <label class="form-label fw-bold text-dark mb-0">2. Ràng buộc Style động:</label>
                <span class="badge bg-primary rounded-pill px-3 py-1">{{ fontSize }}px</span>
              </div>
              <p class="text-muted small mb-2">
                Nhập số hoặc kéo thanh trượt để thay đổi <code>fontSize</code> trong khoảng hợp lệ từ <strong>10px đến 50px</strong>.
              </p>

              <!-- Ô input theo đúng cú pháp đề bài: label > Chọn kích thước chữ: <input type="number" v-model="fontSize" /> -->
              <label class="form-label fw-semibold text-secondary w-100">
                Chọn kích thước chữ:
                <div class="input-group my-2">
                  <span class="input-group-text bg-white">📏 Cỡ:</span>
                  <input 
                    type="number" 
                    class="form-control" 
                    v-model.number="fontSize" 
                    placeholder="Nhập kích thước (10 - 50)"
                  />
                  <span class="input-group-text bg-white">px</span>
                </div>
              </label>

              <!-- Thanh kéo Range trượt mượt mà -->
              <input 
                type="range" 
                class="form-range" 
                min="5" 
                max="65" 
                v-model.number="fontSize" 
              />
              <div class="d-flex justify-content-between text-muted small mt-1">
                <span>5px</span>
                <span class="text-danger fw-bold">Giới hạn: 10px - 50px</span>
                <span>65px</span>
              </div>

              <!-- Preset cỡ chữ mẫu -->
              <div class="d-flex justify-content-between gap-1 mt-3">
                <button class="btn btn-sm btn-outline-secondary rounded-pill px-2 py-1" @click="fontSize = 12">12px</button>
                <button class="btn btn-sm btn-outline-secondary rounded-pill px-2 py-1" @click="fontSize = 16">16px</button>
                <button class="btn btn-sm btn-outline-secondary rounded-pill px-2 py-1" @click="fontSize = 24">24px</button>
                <button class="btn btn-sm btn-outline-secondary rounded-pill px-2 py-1" @click="fontSize = 36">36px</button>
                <button class="btn btn-sm btn-outline-secondary rounded-pill px-2 py-1" @click="fontSize = 48">48px</button>
              </div>
            </div>

            <!-- Cảnh báo điều kiện kích thước đúng theo đề bài -->
            <div 
              v-if="fontSize < 10 || fontSize > 50" 
              class="alert alert-danger py-3 px-3 rounded-3 shadow-sm d-flex align-items-center gap-2 mb-0"
              role="alert"
            >
              <span class="fs-4">⚠️</span>
              <div>
                <strong class="d-block">Kích thước không hợp lệ!</strong>
                <small>Kích thước phải từ 10px đến 50px. Hiện tại là <strong>{{ fontSize }}px</strong>.</small>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Cột 2: Khung Canvas hiển thị văn bản (Live Output Canvas) -->
      <div class="col-lg-7">
        <div class="card border-0 shadow rounded-4 h-100 bg-white overflow-hidden d-flex flex-column">
          <div class="card-header bg-primary text-white py-3 px-4 d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center gap-2">
              <span class="fs-5">🖼️</span>
              <h5 class="mb-0 fw-bold">Khung Xem Trước Văn Bản (Live Canvas)</h5>
            </div>
            <span class="badge bg-white text-primary rounded-pill px-3 py-1 fw-bold">
              Size: {{ fontSize }}px
            </span>
          </div>

          <div class="card-body p-4 p-md-5 d-flex flex-column justify-content-center align-items-center text-center flex-grow-1 canvas-box">
            <!-- Thẻ h1 đúng 100% cú pháp yêu cầu đề bài:
                 <h1 :class="{ active: isActive }" :style="{ fontSize: fontSize + 'px' }">Văn bản có thể thay đổi</h1> -->
            <h1 
              :class="{ active: isActive }" 
              :style="{ fontSize: fontSize + 'px' }"
              class="text-target fw-bold text-break mb-3"
            >
              Văn bản có thể thay đổi
            </h1>

            <p class="text-muted small mt-2">
              Định dạng hiện tại: 
              Màu sắc: <strong :class="isActive ? 'text-danger' : 'text-dark'">{{ isActive ? 'Đỏ (.active)' : 'Mặc định (đen)' }}</strong>
              · Cỡ chữ: <strong class="text-primary">{{ fontSize }}px</strong>
            </p>
          </div>

          <!-- Bảng tra cứu thuộc tính kỹ thuật Vue cho giảng viên xem -->
          <div class="card-footer bg-light p-4 border-top">
            <h6 class="fw-bold text-dark mb-2">📌 Kiểm tra mã Vue 3 đang áp dụng:</h6>
            <div class="bg-dark text-light p-3 rounded-3 font-monospace small">
              <div>&lt;h1</div>
              <div class="ps-3 text-warning">
                :class="{ active: <span class="text-info">{{ isActive }}</span> }"
              </div>
              <div class="ps-3 text-warning">
                :style="{ fontSize: '<span class="text-info">{{ fontSize }}px</span>' }"
              </div>
              <div>&gt;Văn bản có thể thay đổi&lt;/h1&gt;</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from "vue";

// Khai báo các biến phản ứng theo đúng đề bài
const isActive = ref(false);
const fontSize = ref(28);
</script>

<style scoped>
/* Đúng định nghĩa class trong đề bài: .active { color: red; } */
.active {
  color: red !important;
}

.text-target {
  transition: color 0.3s ease, font-size 0.15s ease;
  line-height: 1.3;
}

.canvas-box {
  background: radial-gradient(circle, #ffffff 0%, #f4f6f9 100%);
  border: 2px dashed #dee2e6;
  border-radius: 1rem;
  margin: 1rem;
  min-height: 280px;
}
</style>
