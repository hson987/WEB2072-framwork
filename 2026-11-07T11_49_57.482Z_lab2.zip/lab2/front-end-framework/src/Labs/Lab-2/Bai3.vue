<template>
  <div class="container py-3">
    <!-- Header bài tập -->
    <div class="text-center mb-4">
      <span class="badge bg-info text-dark px-3 py-2 rounded-pill fw-semibold shadow-sm mb-2">
        BÀI 3 (3 ĐIỂM) · VUE 3 COMPOSITION API
      </span>
      <h2 class="fw-bold text-dark display-6">One-way & Two-way Data Binding</h2>
      <p class="text-secondary mx-auto" style="max-width: 650px;">
        Khám phá bản chất của cơ chế liên kết dữ liệu một chiều (One-way) và hai chiều (Two-way) trong Vue.js. Thử gõ văn bản để quan sát sự đồng bộ trạng thái tức thời.
      </p>
    </div>

    <!-- Khối so sánh 2 loại Data Binding -->
    <div class="row g-4 justify-content-center mb-4">
      <!-- Cột 1: One-way Binding (:value readonly) -->
      <div class="col-lg-6">
        <div class="card border-0 shadow rounded-4 h-100 bg-white overflow-hidden">
          <div class="card-header bg-secondary text-white py-3 px-4 d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center gap-2">
              <span class="fs-5">🔒</span>
              <h5 class="mb-0 fw-bold">1. One-way Binding (:value)</h5>
            </div>
            <span class="badge bg-light text-secondary rounded-pill px-3 py-1">Chỉ Đọc (Readonly)</span>
          </div>

          <div class="card-body p-4 d-flex flex-column justify-content-between">
            <div>
              <!-- Mô hình trực quan chiều đi của dữ liệu -->
              <div class="d-flex align-items-center justify-content-center gap-2 p-3 bg-light rounded-3 border mb-3 text-center">
                <span class="badge bg-dark px-3 py-2">JavaScript State (message)</span>
                <span class="fs-4 text-secondary">➡️</span>
                <span class="badge bg-secondary px-3 py-2">HTML Input (View)</span>
              </div>

              <p class="text-muted small mb-3">
                Dữ liệu chỉ truyền theo một chiều từ <strong>Model (State)</strong> sang <strong>View (DOM)</strong>. Người dùng không thể chỉnh sửa dữ liệu trực tiếp trong ô này do thuộc tính <code>readonly</code>.
              </p>

              <!-- Ô input One-way chuẩn theo đề bài -->
              <div class="mb-3">
                <label class="form-label fw-bold text-dark">One-way binding input:</label>
                <div class="input-group">
                  <span class="input-group-text bg-light text-muted">🔒</span>
                  <input 
                    type="text" 
                    class="form-control bg-light text-muted fw-semibold" 
                    :value="message" 
                    readonly 
                  />
                </div>
              </div>
            </div>

            <!-- Code snippet minh họa -->
            <div class="bg-dark text-light p-3 rounded-3 font-monospace small mt-3">
              <span class="text-success">&lt;!-- One-way binding: chỉ đọc --&gt;</span><br>
              &lt;input <span class="text-warning">:value</span>="message" <span class="text-info">readonly</span> /&gt;
            </div>
          </div>
        </div>
      </div>

      <!-- Cột 2: Two-way Binding (v-model) -->
      <div class="col-lg-6">
        <div class="card border-0 shadow rounded-4 h-100 bg-white overflow-hidden">
          <div class="card-header bg-gradient-primary text-white py-3 px-4 d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center gap-2">
              <span class="fs-5">🔄</span>
              <h5 class="mb-0 fw-bold">2. Two-way Binding (v-model)</h5>
            </div>
            <span class="badge bg-white text-primary rounded-pill px-3 py-1">Đồng Bộ 2 Chiều</span>
          </div>

          <div class="card-body p-4 d-flex flex-column justify-content-between">
            <div>
              <!-- Mô hình trực quan chiều đi của dữ liệu -->
              <div class="d-flex align-items-center justify-content-center gap-2 p-3 bg-primary-subtle rounded-3 border border-primary-subtle mb-3 text-center">
                <span class="badge bg-primary px-3 py-2">JavaScript State</span>
                <span class="fs-4 text-primary">⇄</span>
                <span class="badge bg-primary px-3 py-2">HTML Input (View)</span>
              </div>

              <p class="text-muted small mb-3">
                Dữ liệu đồng bộ hai chiều liên tục. Khi người dùng gõ vào ô input, giá trị trong biến <code>message</code> lập tức được cập nhật và phản chiếu đến tất cả nơi sử dụng nó!
              </p>

              <!-- Ô input Two-way chuẩn theo đề bài -->
              <div class="mb-3">
                <label class="form-label fw-bold text-primary">Two-way binding input (Hãy gõ thử vào đây):</label>
                <div class="input-group">
                  <span class="input-group-text bg-primary text-white">✏️</span>
                  <input 
                    type="text" 
                    class="form-control border-primary shadow-sm" 
                    v-model="message" 
                    placeholder="Nhập bất kỳ nội dung nào..."
                  />
                  <button class="btn btn-outline-secondary" type="button" @click="message = ''" title="Xóa trắng">
                    ✖
                  </button>
                </div>
              </div>
            </div>

            <!-- Code snippet minh họa -->
            <div class="bg-dark text-light p-3 rounded-3 font-monospace small mt-3">
              <span class="text-success">&lt;!-- Two-way binding: đồng bộ 2 chiều --&gt;</span><br>
              &lt;input <span class="text-warning">v-model</span>="message" /&gt;
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Khối hiển thị Giá trị hiện tại (Interpolation Output) -->
    <div class="row justify-content-center">
      <div class="col-lg-10">
        <div class="card border-0 shadow rounded-4 bg-white p-4 text-center">
          <div class="d-flex justify-content-between align-items-center mb-3 pb-2 border-bottom">
            <span class="badge bg-danger-subtle text-danger fw-bold px-3 py-2 rounded-pill">
              KẾT QUẢ INTERPOLATION
            </span>
            <div class="text-muted small">
              Độ dài ký tự: <strong class="text-dark">{{ message.length }}</strong> · Số từ: <strong class="text-dark">{{ message.trim() ? message.trim().split(/\s+/).length : 0 }}</strong>
            </div>
          </div>

          <!-- Đúng hiển thị theo đề: Giá trị hiện tại: {{ message }} -->
          <p class="text-muted text-uppercase fw-bold mb-1" style="font-size: 0.85rem;">
            Dòng hiển thị nội suy trong đề bài:
          </p>
          <div class="p-4 bg-light rounded-4 border my-2">
            <p class="fs-4 text-muted mb-1">Giá trị hiện tại:</p>
            <h1 class="display-6 fw-bold text-danger text-break m-0">
              "{{ message }}"
            </h1>
          </div>

          <!-- Nút chọn nội dung nhanh để người chấm dễ thử nghiệm -->
          <div class="d-flex flex-wrap justify-content-center align-items-center gap-2 mt-3">
            <small class="text-muted fw-semibold me-2">Gợi ý thử nhanh:</small>
            <button class="btn btn-sm btn-outline-primary rounded-pill px-3" @click="message = 'Xin chào bạn!'">
              👋 Xin chào bạn!
            </button>
            <button class="btn btn-sm btn-outline-success rounded-pill px-3" @click="message = 'FPT Polytechnic TP.HCM'">
              🏫 FPT Polytechnic
            </button>
            <button class="btn btn-sm btn-outline-warning text-dark rounded-pill px-3" @click="message = 'Vue 3 Composition API cực kỳ tuyệt vời!'">
              ⚡ Vue 3 Rocks!
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from "vue";

// Khởi tạo biến message theo đúng yêu cầu đề bài
const message = ref("Xin chào!");
</script>

<style scoped>
.bg-gradient-primary {
  background: linear-gradient(135deg, #0d6efd 0%, #0a58ca 100%);
}
</style>
