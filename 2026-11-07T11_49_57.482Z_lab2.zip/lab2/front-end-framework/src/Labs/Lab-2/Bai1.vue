<template>
  <div class="container py-3">
    <!-- Header bài tập -->
    <div class="text-center mb-4">
      <span class="badge bg-primary px-3 py-2 rounded-pill fw-semibold shadow-sm mb-2">
        BÀI 1 (2 ĐIỂM) · VUE 3 COMPOSITION API
      </span>
      <h2 class="fw-bold text-dark display-6">Quản Lý Giỏ Hàng Với ref()</h2>
      <p class="text-secondary mx-auto" style="max-width: 650px;">
        Thực hành khai báo biến reactive nguyên thủy với <code>ref()</code>, bắt sự kiện click và ràng buộc thuộc tính <code>:disabled</code> theo điều kiện logic.
      </p>
    </div>

    <div class="row justify-content-center g-4">
      <!-- Cột chính: Giao diện Giỏ hàng thương mại điện tử hiện đại -->
      <div class="col-lg-8">
        <div class="card border-0 shadow rounded-4 overflow-hidden bg-white">
          <!-- Top bar -->
          <div class="card-header bg-gradient-primary text-white py-3 px-4 d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center gap-2">
              <span class="fs-4">🛍️</span>
              <h5 class="mb-0 fw-bold">Chi Tiết Đơn Hàng Của Bạn</h5>
            </div>
            <span class="badge bg-white text-primary rounded-pill px-3 py-2 fw-bold shadow-sm">
              {{ productCount === 0 ? 'Giỏ hàng đang trống' : 'Đã chọn ' + productCount + ' sản phẩm' }}
            </span>
          </div>

          <div class="card-body p-4 p-md-5">
            <!-- Thông tin sản phẩm chính -->
            <div class="card border rounded-4 p-3 mb-4 bg-light shadow-sm">
              <div class="row align-items-center g-3">
                <div class="col-auto">
                  <div class="position-relative">
                    <img 
                      src="https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=240&auto=format&fit=crop&q=80" 
                      alt="Sony WH-1000XM5" 
                      class="rounded-3 shadow-sm object-fit-cover"
                      style="width: 100px; height: 100px;"
                    />
                    <span class="badge bg-danger position-absolute top-0 start-0 m-1 rounded-pill" style="font-size: 0.65rem;">
                      -25%
                    </span>
                  </div>
                </div>
                <div class="col">
                  <span class="badge bg-primary-subtle text-primary mb-1">Chính hãng FPT Shop</span>
                  <h5 class="fw-bold mb-1 text-dark">Tai Nghe Không Dây Sony WH-1000XM5</h5>
                  <div class="text-muted small mb-2">Màu sắc: Đen Nhám (Midnight Black) · Bảo hành 12 tháng</div>
                  <div class="d-flex align-items-baseline gap-2">
                    <span class="fs-4 fw-bold text-primary">{{ unitPrice.toLocaleString('vi-VN') }} VNĐ</span>
                    <span class="text-muted text-decoration-line-through small">8.990.000 VNĐ</span>
                  </div>
                </div>
              </div>
            </div>

            <!-- Khối tương tác số lượng chính (Đáp ứng 100% yêu cầu đề bài) -->
            <div class="text-center py-4 bg-light rounded-4 border mb-4">
              <p class="text-muted text-uppercase fw-bold letter-spacing-1 mb-2">
                Số Lượng Sản Phẩm (Interpolation)
              </p>
              
              <!-- Hiển thị số lượng {{ productCount }} -->
              <div class="d-flex justify-content-center align-items-center gap-4 my-3">
                <!-- Nút Giảm: @click="decreaseCount" và :disabled="productCount === 0" -->
                <button 
                  class="btn btn-outline-danger btn-count d-flex align-items-center justify-content-center shadow-sm"
                  @click="decreaseCount" 
                  :disabled="productCount === 0"
                  title="Giảm số lượng"
                >
                  <span class="fs-4 fw-bold">−</span>
                </button>

                <!-- Số lượng to ở giữa -->
                <div class="count-display fw-bold text-dark px-4 py-2 bg-white rounded-4 border shadow-sm">
                  {{ productCount }}
                </div>

                <!-- Nút Tăng: @click="increaseCount" -->
                <button 
                  class="btn btn-success btn-count d-flex align-items-center justify-content-center shadow-sm"
                  @click="increaseCount"
                  title="Tăng số lượng"
                >
                  <span class="fs-4 fw-bold">+</span>
                </button>
              </div>

              <!-- Hai nút bấm theo nhãn nguyên bản của đề bài -->
              <div class="d-flex justify-content-center gap-3 mt-3">
                <button 
                  class="btn btn-outline-danger px-4 py-2 rounded-pill fw-semibold"
                  @click="decreaseCount"
                  :disabled="productCount === 0"
                >
                  Giảm
                </button>
                <button 
                  class="btn btn-success px-4 py-2 rounded-pill fw-semibold"
                  @click="increaseCount"
                >
                  Tăng
                </button>
              </div>

              <div v-if="productCount === 0" class="text-danger small mt-3 fw-medium">
                ⚠️ Không cho phép giảm số lượng dưới 0 (Đã vô hiệu hóa nút Giảm)
              </div>
            </div>

            <!-- Tóm tắt thanh toán chi tiết -->
            <div class="p-3 bg-white border rounded-3 mb-4">
              <div class="d-flex justify-content-between py-2 border-bottom text-muted">
                <span>Số lượng sản phẩm:</span>
                <span class="fw-bold text-dark">{{ productCount }} món</span>
              </div>
              <div class="d-flex justify-content-between py-2 border-bottom text-muted">
                <span>Phí vận chuyển:</span>
                <span class="text-success fw-semibold">{{ productCount > 0 ? 'Miễn phí (Freeship)' : '0 VNĐ' }}</span>
              </div>
              <div class="d-flex justify-content-between py-2 text-dark fs-5 fw-bold">
                <span>Tổng tiền thanh toán:</span>
                <span class="text-danger">{{ (productCount * unitPrice).toLocaleString('vi-VN') }} VNĐ</span>
              </div>
            </div>

            <!-- Nút giả lập đặt hàng -->
            <button 
              class="btn btn-primary w-100 py-3 rounded-pill fw-bold fs-5 shadow-sm"
              :disabled="productCount === 0"
              @click="checkout"
            >
              🚀 Tiến Hành Thanh Toán ({{ productCount }})
            </button>
          </div>

          <!-- Chân card giải thích kỹ thuật cho giảng viên -->
          <div class="card-footer bg-light p-3 px-4 border-top text-muted small">
            <strong>🔍 Giải thích kỹ thuật Vue 3:</strong>
            <code>const productCount = ref(0);</code> khai báo biến phản ứng. Khi bấm <code>increaseCount</code> hoặc <code>decreaseCount</code>, giá trị <code>productCount.value</code> cập nhật khiến DOM tự động render lại số lượng và tổng tiền mà không cần reload trang.
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from "vue";

// Khai báo biến reactive quản lý số lượng theo đề bài
const productCount = ref(0);
const unitPrice = 6990000; // Đơn giá 6.990.000 VNĐ

// Hàm tăng số lượng
const increaseCount = () => {
  productCount.value++;
};

// Hàm giảm số lượng (không cho phép giảm dưới 0)
const decreaseCount = () => {
  if (productCount.value > 0) {
    productCount.value--;
  }
};

// Hàm thanh toán tương tác thêm
const checkout = () => {
  alert(`Cảm ơn bạn! Đơn hàng gồm ${productCount.value} sản phẩm với tổng tiền ${(productCount.value * unitPrice).toLocaleString('vi-VN')} VNĐ đang được xử lý.`);
};
</script>

<style scoped>
.bg-gradient-primary {
  background: linear-gradient(135deg, #0d6efd 0%, #0a58ca 100%);
}

.btn-count {
  width: 52px;
  height: 52px;
  border-radius: 50%;
  font-size: 1.5rem;
  transition: transform 0.15s ease, box-shadow 0.15s ease;
}

.btn-count:hover:not(:disabled) {
  transform: scale(1.1);
}

.count-display {
  font-size: 2.5rem;
  min-width: 100px;
}

.letter-spacing-1 {
  letter-spacing: 1px;
}

button:disabled {
  cursor: not-allowed;
  opacity: 0.5;
}
</style>
