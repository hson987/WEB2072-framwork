<script setup>
import { ref } from 'vue'
import Bai1 from './Labs/Lab-2/Bai1.vue'
import Bai2 from './Labs/Lab-2/Bai2.vue'
import Bai3 from './Labs/Lab-2/Bai3.vue'
import Bai4 from './Labs/Lab-2/Bai4.vue'

// Tab hiện tại (Mặc định mở Bài 1)
const activeTab = ref('Bai1')
</script>

<template>
  <div class="app-wrapper min-vh-100 d-flex flex-column">
    <!-- Navbar chuyên nghiệp -->
    <header class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top shadow-sm py-3">
      <div class="container">
        <a class="navbar-brand d-flex align-items-center gap-2" href="#">
          <span class="fs-4">⚡</span>
          <div>
            <span class="fw-bold text-white fs-5 d-block leading-tight">FPT POLYTECHNIC</span>
            <small class="text-secondary" style="font-size: 0.75rem;">LAB 2 - REACTIVE STATE & DATA BINDING</small>
          </div>
        </a>

        <!-- Nút chọn bài -->
        <div class="nav-pills-custom d-flex flex-wrap gap-2 p-1 bg-black bg-opacity-25 rounded-pill border border-secondary border-opacity-25">
          <button
            type="button"
            class="btn btn-sm rounded-pill px-3 py-1 fw-semibold transition"
            :class="activeTab === 'Bai1' ? 'btn-primary shadow-sm text-white' : 'btn-link text-white-50 text-decoration-none'"
            @click="activeTab = 'Bai1'"
          >
            Bài 1 (ref)
          </button>
          <button
            type="button"
            class="btn btn-sm rounded-pill px-3 py-1 fw-semibold transition"
            :class="activeTab === 'Bai2' ? 'btn-primary shadow-sm text-white' : 'btn-link text-white-50 text-decoration-none'"
            @click="activeTab = 'Bai2'"
          >
            Bài 2 (reactive)
          </button>
          <button
            type="button"
            class="btn btn-sm rounded-pill px-3 py-1 fw-semibold transition"
            :class="activeTab === 'Bai3' ? 'btn-primary shadow-sm text-white' : 'btn-link text-white-50 text-decoration-none'"
            @click="activeTab = 'Bai3'"
          >
            Bài 3 (Binding)
          </button>
          <button
            type="button"
            class="btn btn-sm rounded-pill px-3 py-1 fw-semibold transition"
            :class="activeTab === 'Bai4' ? 'btn-primary shadow-sm text-white' : 'btn-link text-white-50 text-decoration-none'"
            @click="activeTab = 'Bai4'"
          >
            Bài 4 (Class & Style)
          </button>
        </div>
      </div>
    </header>

    <!-- Nội dung chính của từng bài -->
    <main class="flex-grow-1 py-4">
      <div class="container">
        <Transition name="fade" mode="out-in">
          <div v-if="activeTab === 'Bai1'" key="bai1">
            <Bai1 />
          </div>
          <div v-else-if="activeTab === 'Bai2'" key="bai2">
            <Bai2 />
          </div>
          <div v-else-if="activeTab === 'Bai3'" key="bai3">
            <Bai3 />
          </div>
          <div v-else-if="activeTab === 'Bai4'" key="bai4">
            <Bai4 />
          </div>
        </Transition>
      </div>
    </main>

    <!-- Footer -->
    <footer class="bg-white border-top py-3 text-center text-muted small mt-auto">
      <div class="container">
        © 2026 FPT Polytechnic · Môn Front End Framework (Lab 2: Vue.js 3 + Bootstrap 5)
      </div>
    </footer>
  </div>
</template>

<style>
body {
  margin: 0;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
  background-color: #f4f6f9;
  color: #333333;
}

.leading-tight {
  line-height: 1.1;
}

.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.2s ease, transform 0.2s ease;
}

.fade-enter-from {
  opacity: 0;
  transform: translateY(8px);
}

.fade-leave-to {
  opacity: 0;
  transform: translateY(-8px);
}
</style>

