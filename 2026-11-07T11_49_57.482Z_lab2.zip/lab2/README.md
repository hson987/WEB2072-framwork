# BÁO CÁO THỰC HÀNH LAB 2 - FRONT END FRAMEWORK
**Trường:** FPT POLYTECHNIC  
**Môn:** Front End Framework (Vue.js 3 + Bootstrap 5)  
**Chủ đề:** Reactive State & Data Binding trong Vue.js

---

## 📑 MỤC LỤC BÀI TẬP LAB 2

| Bài | Tên bài | Kiến thức trọng tâm | File mã nguồn | Điểm |
|---|---|---|---|---|
| **Bài 1** | Quản lý giỏ hàng với `ref()` | `ref()`, `.value`, `:disabled`, `@click` | `src/Labs/Lab-2/Bai1.vue` | 2 điểm |
| **Bài 2** | Quản lý thông tin với `reactive()` | `reactive()`, form 2 chiều, validation | `src/Labs/Lab-2/Bai2.vue` | 2 điểm |
| **Bài 3** | One-way và Two-way Binding | `:value` readonly vs `v-model` | `src/Labs/Lab-2/Bai3.vue` | 3 điểm |
| **Bài 4** | Class và Style Binding | `:class="{ active }"`, `:style="{ fontSize }"` | `src/Labs/Lab-2/Bai4.vue` | 3 điểm |

---

## 🚀 CÁCH XEM VÀ CHẠY DỰ ÁN

### Cách 1: Xem nhanh kết quả (Mở ngay bằng trình duyệt)
Click đúp chuột trực tiếp vào file:
👉 **`lab2/preview.html`**  
*(Không cần cài đặt Node.js hay mở server, file chạy đầy đủ tương tác cả 4 bài qua CDN)*.

---

### Cách 2: Chạy chuẩn qua Vite Dev Server
1. Mở Terminal tại thư mục `lab2/front-end-framework`:
   ```bash
   cd front-end-framework
   npm install
   npm run dev
   ```
2. Mở trình duyệt tại địa chỉ: `http://localhost:5173`.

---

## 📂 CẤU TRÚC THƯ MỤC LAB 2
```
lab2/
├── preview.html                     # Xem trực tiếp trên trình duyệt
├── README.md                        # Hướng dẫn chi tiết
└── front-end-framework/
    ├── package.json                 # Cấu hình Vue 3 & Bootstrap 5
    ├── vite.config.js
    ├── index.html
    └── src/
        ├── main.js                  # Nhúng Bootstrap CSS
        ├── App.vue                  # Giao diện chính có tabs chuyển Bài 1 -> 4
        └── Labs/
            └── Lab-2/
                ├── Bai1.vue         # Giỏ hàng với ref()
                ├── Bai2.vue         # Form thông tin với reactive()
                ├── Bai3.vue         # One-way vs Two-way Binding
                └── Bai4.vue         # Class & Style Binding
```

